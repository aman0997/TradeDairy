import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Trade, TradeStatistics, ApiResponse } from '../models/models';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TradeService {
  private apiUrl = `${environment.apiUrl}/trades`;

  constructor(private http: HttpClient) {}

  createTrade(trade: Partial<Trade>): Observable<Trade> {
    return this.http.post<ApiResponse<Trade>>(this.apiUrl, trade)
      .pipe(map(response => response.data));
  }

  closeTrade(tradeId: number, exitPrice: number, exitDate?: Date): Observable<Trade> {
    let params = new HttpParams().set('exitPrice', exitPrice.toString());
    if (exitDate) {
      params = params.set('exitDate', exitDate.toISOString());
    }
    return this.http.put<ApiResponse<Trade>>(`${this.apiUrl}/${tradeId}/close`, null, { params })
      .pipe(map(response => response.data));
  }

  getAllTrades(): Observable<Trade[]> {
    return this.http.get<ApiResponse<Trade[]>>(this.apiUrl)
      .pipe(map(response => response.data));
  }

  getTradesByAccount(accountId: number): Observable<Trade[]> {
    return this.http.get<ApiResponse<Trade[]>>(`${this.apiUrl}/account/${accountId}`)
      .pipe(map(response => response.data));
  }

  getStatistics(): Observable<TradeStatistics> {
    return this.http.get<ApiResponse<TradeStatistics>>(`${this.apiUrl}/statistics`)
      .pipe(map(response => response.data));
  }
}
