# TradeDiary - Quick Start Guide

## Prerequisites
- Java 17+
- Maven 3.6+
- Node.js 18+
- MSSQL Server 2019+ (or Docker)
- Git

## Quick Setup with Docker (Recommended)

### 1. Start All Services
```bash
# Clone the repository
git clone <your-repo-url>
cd tradediary-app

# Start all services with Docker Compose
docker-compose up -d

# Check logs
docker-compose logs -f
```

### 2. Access the Application
- Frontend: http://localhost:4200
- Backend API: http://localhost:8080/api
- Swagger UI: http://localhost:8080/api/swagger-ui.html

### 3. Stop Services
```bash
docker-compose down
```

## Manual Setup

### Backend Setup

1. **Install MSSQL Server**
   - Download from Microsoft website
   - Or use Docker:
     ```bash
     docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourStrong@Passw0rd" \
       -p 1433:1433 --name sql-server \
       -d mcr.microsoft.com/mssql/server:2022-latest
     ```

2. **Create Database**
   ```bash
   # Connect to MSSQL
   sqlcmd -S localhost -U sa -P YourStrong@Passw0rd

   # Run setup script
   sqlcmd -S localhost -U sa -P YourStrong@Passw0rd -i database-setup.sql
   ```

3. **Configure Backend**
   ```bash
   cd backend
   
   # Update src/main/resources/application.properties
   # Change database credentials if needed
   
   # Build and run
   mvn clean install
   mvn spring-boot:run
   ```

   Backend starts at: http://localhost:8080

### Frontend Setup

1. **Install Dependencies**
   ```bash
   cd frontend
   npm install
   ```

2. **Configure API URL**
   ```typescript
   // Edit src/environments/environment.ts
   export const environment = {
     production: false,
     apiUrl: 'http://localhost:8080/api'
   };
   ```

3. **Run Development Server**
   ```bash
   ng serve
   ```

   Frontend starts at: http://localhost:4200

## Testing the Application

### 1. Register a New User
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123",
    "fullName": "Test User"
  }'
```

### 2. Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "password123"
  }'
```

Save the token from the response.

### 3. Create Trading Account
```bash
curl -X POST http://localhost:8080/api/accounts \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "accountName": "My Demo Account",
    "brokerName": "Test Broker",
    "accountType": "DEMO",
    "initialBalance": 10000,
    "currency": "USD"
  }'
```

### 4. Create a Trade
```bash
curl -X POST http://localhost:8080/api/trades \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "accountId": 1,
    "symbol": "AAPL",
    "tradeType": "STOCK",
    "positionType": "LONG",
    "entryPrice": 150.50,
    "quantity": 10,
    "stopLoss": 145.00,
    "takeProfit": 160.00,
    "entryDate": "2024-02-16T10:00:00",
    "strategy": "Breakout",
    "notes": "Strong bullish momentum"
  }'
```

### 5. Get Statistics
```bash
curl -X GET http://localhost:8080/api/trades/statistics \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## Default Login Credentials

If you run the database setup script, a test user is created:
- Username: `testuser`
- Password: `password`

## Common Issues & Solutions

### Issue: Cannot connect to MSSQL
**Solution**: 
- Ensure MSSQL is running: `docker ps` or check Windows services
- Check firewall settings
- Verify connection string in application.properties

### Issue: Port already in use
**Solution**:
```bash
# Backend (8080)
lsof -ti:8080 | xargs kill -9

# Frontend (4200)
lsof -ti:4200 | xargs kill -9

# MSSQL (1433)
lsof -ti:1433 | xargs kill -9
```

### Issue: Authentication fails
**Solution**:
- Clear browser cache and localStorage
- Verify JWT secret is configured
- Check token expiration settings

### Issue: CORS errors
**Solution**:
- Verify CORS configuration in SecurityConfig.java
- Check allowed origins in application.properties
- Ensure frontend URL matches CORS settings

## Project Structure Overview

```
tradediary-app/
├── backend/              # Spring Boot application
│   ├── src/main/java/
│   │   └── com/tradediary/
│   │       ├── entity/   # Database entities
│   │       ├── repository/  # Data access
│   │       ├── service/  # Business logic
│   │       ├── controller/  # REST endpoints
│   │       ├── dto/      # API contracts
│   │       ├── security/ # Authentication
│   │       └── config/   # Configuration
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
│
└── frontend/            # Angular application
    ├── src/
    │   ├── app/
    │   │   ├── components/  # UI components
    │   │   ├── services/    # API communication
    │   │   ├── models/      # TypeScript interfaces
    │   │   └── guards/      # Route protection
    │   └── environments/
    ├── package.json
    └── angular.json
```

## API Documentation

Once the backend is running, access interactive API documentation at:
- Swagger UI: http://localhost:8080/api/swagger-ui.html
- API Docs JSON: http://localhost:8080/api/api-docs

## Development Workflow

1. **Make Changes**
   - Backend: Edit Java files, Maven auto-recompiles
   - Frontend: Edit TypeScript/HTML, Angular auto-reloads

2. **Run Tests**
   ```bash
   # Backend
   cd backend && mvn test
   
   # Frontend
   cd frontend && ng test
   ```

3. **Build for Production**
   ```bash
   # Backend
   cd backend && mvn clean package
   
   # Frontend
   cd frontend && ng build --prod
   ```

## Next Steps

1. Explore the API using Swagger UI
2. Customize the frontend components
3. Add additional features
4. Deploy to cloud platform
5. Set up CI/CD pipeline

## Support

For issues and questions:
1. Check the README.md
2. Review API documentation
3. Check logs: `docker-compose logs`
4. Create an issue in the repository

## Additional Resources

- [Spring Boot Documentation](https://spring.io/projects/spring-boot)
- [Angular Documentation](https://angular.io/docs)
- [MSSQL Documentation](https://docs.microsoft.com/en-us/sql/)
- [JWT.io](https://jwt.io/)

Happy Trading! 📈
