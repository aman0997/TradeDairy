# Complete Setup Instructions for TradeDiary

## Overview
This is a complete full-stack trading journal application inspired by tradediary.in.
- **Backend**: Spring Boot 3.2.1 with MSSQL database
- **Frontend**: Angular 17
- **Features**: User authentication, trade logging, performance analytics, account management

## What You've Received

```
tradediary-app/
├── README.md                  # Complete project documentation
├── QUICKSTART.md             # Quick start guide
├── PROJECT-STRUCTURE.md      # Detailed file structure
├── database-setup.sql        # Database initialization script
├── docker-compose.yml        # Docker orchestration
├── backend/                  # Spring Boot application
│   ├── pom.xml              # Maven dependencies
│   ├── Dockerfile           # Backend Docker config
│   └── src/                 # Java source code
└── frontend/                 # Angular application
    ├── package.json         # NPM dependencies
    ├── Dockerfile           # Frontend Docker config
    └── src/                 # TypeScript/Angular code
```

## Quick Start (3 Options)

### Option 1: Docker (Easiest - Recommended)

1. **Prerequisites**: Docker and Docker Compose installed

2. **Start Everything**:
   ```bash
   cd tradediary-app
   docker-compose up -d
   ```

3. **Access**:
   - Frontend: http://localhost:4200
   - Backend API: http://localhost:8080/api
   - Swagger UI: http://localhost:8080/api/swagger-ui.html

4. **Stop**:
   ```bash
   docker-compose down
   ```

### Option 2: Manual Setup

#### Backend Setup

1. **Prerequisites**:
   - Java 17+
   - Maven 3.6+
   - MSSQL Server 2019+

2. **Setup Database**:
   ```bash
   # Start MSSQL (or use existing installation)
   docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourStrong@Passw0rd" \
     -p 1433:1433 --name sql-server \
     -d mcr.microsoft.com/mssql/server:2022-latest

   # Create database
   sqlcmd -S localhost -U sa -P YourStrong@Passw0rd -i database-setup.sql
   ```

3. **Configure Backend**:
   ```bash
   cd backend
   # Edit src/main/resources/application.properties
   # Update database credentials if needed
   ```

4. **Run Backend**:
   ```bash
   mvn clean install
   mvn spring-boot:run
   ```

#### Frontend Setup

1. **Prerequisites**:
   - Node.js 18+
   - npm

2. **Install & Run**:
   ```bash
   cd frontend
   npm install
   ng serve
   ```

### Option 3: IDE Setup

#### IntelliJ IDEA
1. Open `backend` folder as Maven project
2. Configure JDK 17
3. Run `TradeDiaryApplication.java`

#### VS Code (Frontend)
1. Open `frontend` folder
2. Install Angular extension
3. Run `npm install` in terminal
4. Run `ng serve`

## First Time Use

### 1. Create Your Account
Visit http://localhost:4200 and register:
- Username: your_username
- Email: your@email.com
- Password: secure_password

### 2. Create Trading Account
After login:
1. Go to "Accounts" section
2. Click "New Account"
3. Fill in:
   - Account Name: "My Demo Account"
   - Broker: "Interactive Brokers"
   - Type: DEMO or LIVE
   - Initial Balance: 10000
   - Currency: USD

### 3. Log Your First Trade
1. Go to "Trades" section
2. Click "New Trade"
3. Fill in trade details:
   - Symbol: AAPL
   - Type: STOCK
   - Position: LONG
   - Entry Price: 150.50
   - Quantity: 10
   - Stop Loss: 145.00 (optional)
   - Take Profit: 160.00 (optional)

### 4. View Statistics
Go to "Dashboard" to see:
- Win rate
- Profit factor
- Total P&L
- Average win/loss
- Trade charts and analytics

## Testing the API

### Using cURL

**Register**:
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123"
  }'
```

**Login**:
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "password123"
  }'
```

**Create Trade** (replace TOKEN):
```bash
curl -X POST http://localhost:8080/api/trades \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "accountId": 1,
    "symbol": "AAPL",
    "tradeType": "STOCK",
    "positionType": "LONG",
    "entryPrice": 150.50,
    "quantity": 10,
    "entryDate": "2024-02-16T10:00:00"
  }'
```

### Using Swagger UI

1. Open: http://localhost:8080/api/swagger-ui.html
2. Click "Authorize" button
3. Login to get token
4. Paste token in format: `Bearer YOUR_TOKEN`
5. Test all endpoints interactively

## Configuration

### Backend Configuration
File: `backend/src/main/resources/application.properties`

Key settings:
```properties
# Database
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=tradediary_db
spring.datasource.username=sa
spring.datasource.password=YourStrong@Passw0rd

# JWT
jwt.secret=your-secret-key-change-in-production
jwt.expiration=86400000

# Server
server.port=8080
```

### Frontend Configuration
File: `frontend/src/environments/environment.ts`

```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api'
};
```

## Common Issues & Solutions

### Port Already in Use
```bash
# Kill process on port 8080
lsof -ti:8080 | xargs kill -9

# Kill process on port 4200
lsof -ti:4200 | xargs kill -9
```

### Database Connection Failed
1. Verify MSSQL is running: `docker ps` or check Windows services
2. Check credentials in application.properties
3. Verify port 1433 is accessible
4. Check firewall settings

### CORS Errors
1. Verify frontend URL in backend CORS configuration
2. Check `cors.allowed-origins` in application.properties
3. Restart both frontend and backend

### JWT Authentication Failed
1. Clear browser localStorage
2. Verify JWT secret matches in properties file
3. Check token expiration time
4. Re-login to get new token

## Next Steps

1. **Customize the UI**: Modify Angular components in `frontend/src/app/components/`
2. **Add Features**: Extend backend services and controllers
3. **Deploy**: Use Docker Compose for cloud deployment (AWS, Azure, GCP)
4. **Secure**: Update JWT secret, enable HTTPS, configure production database
5. **Scale**: Add Redis for caching, implement rate limiting

## Key Features

✅ User authentication with JWT
✅ Multiple trading accounts per user
✅ Trade logging with automatic P&L calculation
✅ Performance statistics and analytics
✅ Win rate and profit factor calculation
✅ Strategy and market condition tracking
✅ RESTful API with Swagger documentation
✅ Responsive Angular frontend
✅ MSSQL database with JPA/Hibernate
✅ Docker support for easy deployment

## Architecture Highlights

- **3-Tier Architecture**: Presentation (Angular) → Business (Spring Boot) → Data (MSSQL)
- **Security**: JWT-based stateless authentication
- **ORM**: Spring Data JPA with Hibernate
- **API Documentation**: Swagger/OpenAPI 3.0
- **Containerization**: Docker and Docker Compose ready

## Support & Documentation

- **README.md**: Complete project overview
- **QUICKSTART.md**: Fast setup guide
- **PROJECT-STRUCTURE.md**: Detailed file organization
- **Swagger UI**: Interactive API documentation at /swagger-ui.html

## Development Tips

1. **Hot Reload**:
   - Backend: Use Spring Boot DevTools
   - Frontend: `ng serve` auto-reloads on changes

2. **Database Changes**:
   - Update Entity classes
   - Hibernate auto-updates schema
   - Or set `ddl-auto=create` for fresh start

3. **Add New Endpoint**:
   - Create method in Controller
   - Implement in Service
   - Test in Swagger UI

4. **Add New Component**:
   - `ng generate component name`
   - Update routing
   - Create service methods

## Production Deployment

1. Build frontend: `ng build --prod`
2. Package backend: `mvn clean package`
3. Configure production database
4. Set environment variables
5. Use `docker-compose up -d` with production config
6. Configure reverse proxy (Nginx)
7. Enable SSL/TLS
8. Set up monitoring and logging

## Contact & Support

For issues, questions, or contributions:
1. Check documentation files
2. Review Swagger API docs
3. Check application logs
4. Create GitHub issue

---

**Happy Trading! 📈**

Built with ❤️ using Spring Boot and Angular
