-- TradeDiary Database Setup Script for MSSQL
-- Run this script to create the database and initial setup

-- Create Database
CREATE DATABASE tradediary_db;
GO

USE tradediary_db;
GO

-- Note: Tables will be auto-created by Hibernate with spring.jpa.hibernate.ddl-auto=update
-- This script is for manual database creation if needed

-- Optional: Create separate schema
CREATE SCHEMA tradediary;
GO

-- Sample insert statements (for testing)

-- Insert sample user (password is 'password' hashed with BCrypt)
INSERT INTO users (username, email, password, full_name, role, is_active, is_verified, created_at, updated_at)
VALUES ('testuser', 'test@example.com', '$2a$10$slYQm8N7vVLr2SqFaMvUTe0gVzp7nMCXCCK0.XtNm8VlQR5kpU4kS', 'Test User', 'USER', 1, 1, GETDATE(), GETDATE());
GO

-- Create indexes for better performance
CREATE INDEX idx_trades_user_id ON trades(user_id);
CREATE INDEX idx_trades_account_id ON trades(account_id);
CREATE INDEX idx_trades_symbol ON trades(symbol);
CREATE INDEX idx_trades_status ON trades(status);
CREATE INDEX idx_trades_entry_date ON trades(entry_date);
CREATE INDEX idx_trading_accounts_user_id ON trading_accounts(user_id);
GO

-- Create view for trade summary
CREATE VIEW vw_trade_summary AS
SELECT 
    t.id,
    t.symbol,
    t.trade_type,
    t.position_type,
    t.entry_price,
    t.exit_price,
    t.quantity,
    t.net_profit_loss,
    t.status,
    t.entry_date,
    t.exit_date,
    ta.account_name,
    u.username
FROM trades t
INNER JOIN trading_accounts ta ON t.account_id = ta.id
INNER JOIN users u ON t.user_id = u.id;
GO

-- Create stored procedure for user statistics
CREATE PROCEDURE sp_GetUserStatistics
    @userId BIGINT
AS
BEGIN
    SELECT 
        COUNT(*) as total_trades,
        SUM(CASE WHEN net_profit_loss > 0 THEN 1 ELSE 0 END) as winning_trades,
        SUM(CASE WHEN net_profit_loss < 0 THEN 1 ELSE 0 END) as losing_trades,
        CAST(SUM(CASE WHEN net_profit_loss > 0 THEN 1 ELSE 0 END) AS FLOAT) / 
            NULLIF(COUNT(*), 0) * 100 as win_rate,
        SUM(CASE WHEN net_profit_loss > 0 THEN net_profit_loss ELSE 0 END) as total_profit,
        SUM(CASE WHEN net_profit_loss < 0 THEN net_profit_loss ELSE 0 END) as total_loss,
        SUM(net_profit_loss) as net_profit_loss,
        AVG(CASE WHEN net_profit_loss > 0 THEN net_profit_loss ELSE NULL END) as avg_win,
        AVG(CASE WHEN net_profit_loss < 0 THEN net_profit_loss ELSE NULL END) as avg_loss,
        MAX(net_profit_loss) as largest_win,
        MIN(net_profit_loss) as largest_loss
    FROM trades
    WHERE user_id = @userId AND status = 'CLOSED';
END;
GO

PRINT 'Database setup completed successfully!';
