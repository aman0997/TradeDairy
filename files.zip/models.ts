// src/app/models/user.model.ts
export interface User {
  id: number;
  username: string;
  email: string;
  fullName?: string;
  phoneNumber?: string;
  role: 'USER' | 'ADMIN' | 'PREMIUM';
  isActive: boolean;
  isVerified: boolean;
  createdAt: Date;
}

// src/app/models/trading-account.model.ts
export interface TradingAccount {
  id: number;
  accountName: string;
  brokerName?: string;
  accountNumber?: string;
  accountType: 'DEMO' | 'LIVE' | 'PAPER';
  initialBalance: number;
  currentBalance: number;
  currency: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// src/app/models/trade.model.ts
export interface Trade {
  id: number;
  accountId: number;
  accountName: string;
  symbol: string;
  tradeType: 'STOCK' | 'FOREX' | 'CRYPTO' | 'FUTURES' | 'OPTIONS';
  positionType: 'LONG' | 'SHORT';
  entryPrice: number;
  exitPrice?: number;
  quantity: number;
  stopLoss?: number;
  takeProfit?: number;
  profitLoss?: number;
  profitLossPercentage?: number;
  commission?: number;
  netProfitLoss?: number;
  status: 'OPEN' | 'CLOSED' | 'CANCELLED';
  entryDate: Date;
  exitDate?: Date;
  strategy?: string;
  marketCondition?: string;
  notes?: string;
  screenshotUrl?: string;
  tags?: string[];
  createdAt: Date;
  updatedAt: Date;
}

// src/app/models/statistics.model.ts
export interface TradeStatistics {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  totalProfit: number;
  totalLoss: number;
  netProfitLoss: number;
  averageWin: number;
  averageLoss: number;
  profitFactor: number;
  largestWin: number;
  largestLoss: number;
  averageRiskReward: number;
}

// src/app/models/auth.model.ts
export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  fullName?: string;
  phoneNumber?: string;
}

export interface AuthResponse {
  token: string;
  type: string;
  userId: number;
  username: string;
  email: string;
  role: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}
