# TradeDiary Project Structure

## Complete File Listing

### Backend (Spring Boot + MSSQL)

```
backend/
├── pom.xml                                    # Maven dependencies
├── Dockerfile                                 # Docker build configuration
├── src/
│   ├── main/
│   │   ├── java/com/tradediary/
│   │   │   ├── TradeDiaryApplication.java    # Main application class
│   │   │   │
│   │   │   ├── config/
│   │   │   │   └── SecurityConfig.java       # Spring Security configuration
│   │   │   │
│   │   │   ├── controller/
│   │   │   │   └── Controllers.java          # REST API endpoints
│   │   │   │       ├── AuthController
│   │   │   │       ├── TradingAccountController
│   │   │   │       └── TradeController
│   │   │   │
│   │   │   ├── dto/
│   │   │   │   └── DTOs.java                 # Data Transfer Objects
│   │   │   │       ├── LoginRequest
│   │   │   │       ├── RegisterRequest
│   │   │   │       ├── AuthResponse
│   │   │   │       ├── UserDTO
│   │   │   │       ├── TradingAccountRequest
│   │   │   │       ├── TradingAccountDTO
│   │   │   │       ├── TradeRequest
│   │   │   │       ├── TradeDTO
│   │   │   │       ├── TradeStatistics
│   │   │   │       └── ApiResponse<T>
│   │   │   │
│   │   │   ├── entity/
│   │   │   │   ├── User.java                 # User entity (JPA)
│   │   │   │   ├── TradingAccount.java       # Trading account entity
│   │   │   │   └── Trade.java                # Trade entity
│   │   │   │
│   │   │   ├── exception/
│   │   │   │   └── ResourceNotFoundException.java
│   │   │   │
│   │   │   ├── repository/
│   │   │   │   └── Repositories.java         # JPA Repositories
│   │   │   │       ├── UserRepository
│   │   │   │       ├── TradingAccountRepository
│   │   │   │       └── TradeRepository
│   │   │   │
│   │   │   ├── security/
│   │   │   │   ├── JwtUtil.java              # JWT token utility
│   │   │   │   └── JwtAuthenticationFilter.java
│   │   │   │
│   │   │   └── service/
│   │   │       ├── Services.java             # Business logic services
│   │   │       │   ├── AuthService
│   │   │       │   ├── TradingAccountService
│   │   │       │   └── TradeService
│   │   │       └── CustomUserDetailsService.java
│   │   │
│   │   └── resources/
│   │       └── application.properties        # Application configuration
│   │
│   └── test/java/com/tradediary/            # Unit tests
│
└── target/                                    # Build output (generated)

```

### Frontend (Angular)

```
frontend/
├── package.json                              # NPM dependencies
├── tsconfig.json                             # TypeScript configuration
├── angular.json                              # Angular CLI configuration
├── Dockerfile                                # Docker build configuration
├── nginx.conf                                # Nginx configuration for production
│
├── src/
│   ├── app/
│   │   ├── app.module.ts                    # Root module
│   │   ├── app-routing.module.ts            # Routing configuration
│   │   ├── app.component.ts                 # Root component
│   │   ├── app.component.html
│   │   ├── app.component.css
│   │   │
│   │   ├── components/
│   │   │   ├── auth/                        # Authentication components
│   │   │   │   ├── login/
│   │   │   │   │   ├── login.component.ts
│   │   │   │   │   ├── login.component.html
│   │   │   │   │   └── login.component.css
│   │   │   │   ├── register/
│   │   │   │   │   ├── register.component.ts
│   │   │   │   │   ├── register.component.html
│   │   │   │   │   └── register.component.css
│   │   │   │   └── auth.module.ts
│   │   │   │
│   │   │   ├── dashboard/                   # Dashboard components
│   │   │   │   ├── dashboard.component.ts
│   │   │   │   ├── dashboard.component.html
│   │   │   │   ├── dashboard.component.css
│   │   │   │   ├── statistics/
│   │   │   │   │   └── statistics.component.ts
│   │   │   │   └── dashboard.module.ts
│   │   │   │
│   │   │   ├── trades/                      # Trade management
│   │   │   │   ├── trade-list/
│   │   │   │   │   ├── trade-list.component.ts
│   │   │   │   │   ├── trade-list.component.html
│   │   │   │   │   └── trade-list.component.css
│   │   │   │   ├── trade-form/
│   │   │   │   │   ├── trade-form.component.ts
│   │   │   │   │   ├── trade-form.component.html
│   │   │   │   │   └── trade-form.component.css
│   │   │   │   ├── trade-detail/
│   │   │   │   │   └── trade-detail.component.ts
│   │   │   │   └── trades.module.ts
│   │   │   │
│   │   │   ├── accounts/                    # Account management
│   │   │   │   ├── account-list/
│   │   │   │   │   └── account-list.component.ts
│   │   │   │   ├── account-form/
│   │   │   │   │   └── account-form.component.ts
│   │   │   │   └── accounts.module.ts
│   │   │   │
│   │   │   └── shared/                      # Shared components
│   │   │       ├── header/
│   │   │       │   └── header.component.ts
│   │   │       ├── sidebar/
│   │   │       │   └── sidebar.component.ts
│   │   │       └── footer/
│   │   │           └── footer.component.ts
│   │   │
│   │   ├── services/
│   │   │   ├── auth.service.ts              # Authentication service
│   │   │   ├── trade.service.ts             # Trade service
│   │   │   └── account.service.ts           # Account service
│   │   │
│   │   ├── models/
│   │   │   └── models.ts                    # TypeScript interfaces
│   │   │       ├── User
│   │   │       ├── TradingAccount
│   │   │       ├── Trade
│   │   │       ├── TradeStatistics
│   │   │       ├── LoginRequest
│   │   │       ├── RegisterRequest
│   │   │       ├── AuthResponse
│   │   │       └── ApiResponse<T>
│   │   │
│   │   ├── guards/
│   │   │   └── auth.guard.ts                # Route protection
│   │   │
│   │   └── interceptors/
│   │       ├── jwt.interceptor.ts           # JWT token interceptor
│   │       └── error.interceptor.ts         # Error handling
│   │
│   ├── assets/                              # Static assets
│   │   ├── images/
│   │   ├── styles/
│   │   └── fonts/
│   │
│   ├── environments/
│   │   ├── environment.ts                   # Development environment
│   │   └── environment.prod.ts              # Production environment
│   │
│   ├── index.html                           # Main HTML file
│   ├── main.ts                              # Application entry point
│   └── styles.css                           # Global styles
│
└── dist/                                     # Build output (generated)

```

### Database

```
database/
├── database-setup.sql                        # MSSQL setup script
└── sample-data.sql                          # Sample data for testing
```

### Root Level Files

```
tradediary-app/
├── README.md                                 # Project documentation
├── QUICKSTART.md                            # Quick start guide
├── PROJECT-STRUCTURE.md                     # This file
├── docker-compose.yml                       # Docker Compose configuration
├── .gitignore                               # Git ignore rules
└── LICENSE                                  # License file
```

## Key Files Description

### Backend

- **pom.xml**: Maven project configuration with all dependencies (Spring Boot, MSSQL, Security, JWT, etc.)
- **application.properties**: Database connection, JWT configuration, server settings
- **SecurityConfig.java**: Spring Security setup with JWT, CORS, authentication
- **JwtUtil.java**: JWT token generation and validation
- **Entities**: JPA entities mapping to database tables
- **Repositories**: Spring Data JPA repositories for data access
- **Services**: Business logic layer
- **Controllers**: REST API endpoints
- **DTOs**: Data transfer objects for API communication

### Frontend

- **package.json**: NPM dependencies (Angular, RxJS, Chart.js, etc.)
- **app.module.ts**: Root Angular module with imports and providers
- **app-routing.module.ts**: Application routing configuration
- **Services**: HTTP client services for API communication
- **Components**: UI components organized by feature
- **Guards**: Route protection (authentication check)
- **Interceptors**: HTTP interceptors for JWT and error handling
- **Models**: TypeScript interfaces matching backend DTOs

### Database

- **Entities**:
  - Users (authentication and profile)
  - TradingAccounts (multiple accounts per user)
  - Trades (trade records with P&L calculations)
  - TradeTags (many-to-many relationship)

## Configuration Files

### Environment Variables

Backend (application.properties):
- `spring.datasource.url`: MSSQL connection string
- `spring.datasource.username`: Database username
- `spring.datasource.password`: Database password
- `jwt.secret`: JWT signing secret
- `jwt.expiration`: Token expiration time
- `cors.allowed-origins`: Allowed CORS origins

Frontend (environment.ts):
- `apiUrl`: Backend API base URL

### Docker Configuration

- **docker-compose.yml**: Orchestrates MSSQL, Backend, and Frontend containers
- **backend/Dockerfile**: Multi-stage build for Spring Boot app
- **frontend/Dockerfile**: Multi-stage build for Angular app with Nginx
- **nginx.conf**: Nginx reverse proxy configuration

## API Endpoints

### Authentication
- POST `/api/auth/register` - User registration
- POST `/api/auth/login` - User login

### Accounts
- GET `/api/accounts` - Get all accounts
- POST `/api/accounts` - Create account
- GET `/api/accounts/{id}` - Get account by ID

### Trades
- GET `/api/trades` - Get all trades
- POST `/api/trades` - Create trade
- PUT `/api/trades/{id}/close` - Close trade
- GET `/api/trades/account/{accountId}` - Get trades by account
- GET `/api/trades/statistics` - Get trade statistics

## Technologies Used

### Backend
- Spring Boot 3.2.1
- Spring Security
- Spring Data JPA
- Hibernate
- JWT (io.jsonwebtoken)
- MSSQL JDBC Driver
- Lombok
- ModelMapper
- SpringDoc OpenAPI (Swagger)

### Frontend
- Angular 17
- TypeScript 5.2
- RxJS 7.8
- Chart.js 4.4
- ng2-charts

### Database
- Microsoft SQL Server 2022

### DevOps
- Docker
- Docker Compose
- Maven
- NPM
- Nginx

## Build Commands

### Backend
```bash
mvn clean install          # Build project
mvn spring-boot:run        # Run application
mvn test                   # Run tests
mvn package                # Create JAR file
```

### Frontend
```bash
npm install                # Install dependencies
ng serve                   # Development server
ng build                   # Build for development
ng build --prod            # Build for production
ng test                    # Run tests
```

### Docker
```bash
docker-compose up          # Start all services
docker-compose down        # Stop all services
docker-compose logs -f     # View logs
docker-compose build       # Rebuild images
```

This structure provides a complete, production-ready trading journal application with proper separation of concerns, security, and scalability.
