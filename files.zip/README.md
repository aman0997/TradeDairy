# TradeDiary - Trading Journal Application

A full-stack trading journal application inspired by tradediary.in, built with Spring Boot backend, MSSQL database, and Angular frontend.

## Features

- User authentication and authorization (JWT-based)
- Trading account management
- Trade logging and tracking
- Performance statistics and analytics
- Win/loss ratio calculations
- Profit factor analysis
- Trade categorization by strategy and market conditions
- RESTful API architecture
- Responsive Angular frontend

## Technology Stack

### Backend
- **Framework**: Spring Boot 3.2.1
- **Database**: Microsoft SQL Server (MSSQL)
- **Security**: Spring Security with JWT
- **ORM**: Spring Data JPA with Hibernate
- **Build Tool**: Maven
- **Java Version**: 17

### Frontend
- **Framework**: Angular 17
- **HTTP Client**: Angular HttpClient
- **State Management**: RxJS
- **Charts**: Chart.js with ng2-charts
- **Styling**: CSS3

## Project Structure

```
tradediary-app/
├── backend/                           # Spring Boot Backend
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/tradediary/
│   │   │   │   ├── config/            # Configuration classes
│   │   │   │   │   └── SecurityConfig.java
│   │   │   │   ├── controller/        # REST Controllers
│   │   │   │   │   └── Controllers.java
│   │   │   │   ├── dto/               # Data Transfer Objects
│   │   │   │   │   └── DTOs.java
│   │   │   │   ├── entity/            # JPA Entities
│   │   │   │   │   ├── User.java
│   │   │   │   │   ├── TradingAccount.java
│   │   │   │   │   └── Trade.java
│   │   │   │   ├── exception/         # Custom Exceptions
│   │   │   │   │   └── ResourceNotFoundException.java
│   │   │   │   ├── repository/        # JPA Repositories
│   │   │   │   │   └── Repositories.java
│   │   │   │   ├── security/          # Security Components
│   │   │   │   │   ├── JwtUtil.java
│   │   │   │   │   └── JwtAuthenticationFilter.java
│   │   │   │   ├── service/           # Business Logic
│   │   │   │   │   ├── Services.java
│   │   │   │   │   └── CustomUserDetailsService.java
│   │   │   │   └── TradeDiaryApplication.java
│   │   │   └── resources/
│   │   │       └── application.properties
│   │   └── test/
│   └── pom.xml
│
└── frontend/                          # Angular Frontend
    ├── src/
    │   ├── app/
    │   │   ├── components/
    │   │   │   ├── auth/             # Authentication components
    │   │   │   ├── dashboard/        # Dashboard components
    │   │   │   ├── trades/           # Trade management components
    │   │   │   ├── accounts/         # Account management components
    │   │   │   └── shared/           # Shared components
    │   │   ├── services/             # Angular Services
    │   │   │   ├── auth.service.ts
    │   │   │   ├── trade.service.ts
    │   │   │   └── account.service.ts
    │   │   ├── models/               # TypeScript Models
    │   │   │   └── models.ts
    │   │   ├── guards/               # Route Guards
    │   │   └── interceptors/         # HTTP Interceptors
    │   ├── assets/
    │   └── environments/
    ├── package.json
    └── tsconfig.json
```

## Database Schema

### Users Table
- id (PK, IDENTITY)
- username (UNIQUE, NOT NULL)
- email (UNIQUE, NOT NULL)
- password (NOT NULL)
- full_name
- phone_number
- role (ENUM: USER, ADMIN, PREMIUM)
- is_active
- is_verified
- verification_token
- reset_token
- created_at
- updated_at

### Trading Accounts Table
- id (PK, IDENTITY)
- user_id (FK -> Users)
- account_name (NOT NULL)
- broker_name
- account_number
- account_type (ENUM: DEMO, LIVE, PAPER)
- initial_balance
- current_balance
- currency
- is_active
- created_at
- updated_at

### Trades Table
- id (PK, IDENTITY)
- user_id (FK -> Users)
- account_id (FK -> TradingAccounts)
- symbol (NOT NULL)
- trade_type (ENUM: STOCK, FOREX, CRYPTO, FUTURES, OPTIONS)
- position_type (ENUM: LONG, SHORT)
- entry_price (NOT NULL)
- exit_price
- quantity (NOT NULL)
- stop_loss
- take_profit
- profit_loss
- profit_loss_percentage
- commission
- net_profit_loss
- status (ENUM: OPEN, CLOSED, CANCELLED)
- entry_date (NOT NULL)
- exit_date
- strategy
- market_condition
- notes (TEXT)
- screenshot_url
- created_at
- updated_at

### Trade Tags Table
- trade_id (FK -> Trades)
- tag

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Trading Accounts
- `GET /api/accounts` - Get all user accounts
- `POST /api/accounts` - Create new trading account
- `GET /api/accounts/{id}` - Get account by ID

### Trades
- `GET /api/trades` - Get all user trades
- `POST /api/trades` - Create new trade
- `PUT /api/trades/{id}/close` - Close a trade
- `GET /api/trades/account/{accountId}` - Get trades by account
- `GET /api/trades/statistics` - Get trade statistics

## Setup Instructions

### Prerequisites
- Java 17 or higher
- Maven 3.6+
- Node.js 18+ and npm
- Microsoft SQL Server 2019+ or Azure SQL Database
- Git

### Backend Setup

1. **Configure Database**
   ```bash
   # Create database in MSSQL
   CREATE DATABASE tradediary_db;
   ```

2. **Update application.properties**
   ```properties
   spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=tradediary_db
   spring.datasource.username=your_username
   spring.datasource.password=your_password
   jwt.secret=your_secret_key_here
   ```

3. **Build and Run**
   ```bash
   cd backend
   mvn clean install
   mvn spring-boot:run
   ```
   
   Backend will start on `http://localhost:8080`

### Frontend Setup

1. **Install Dependencies**
   ```bash
   cd frontend
   npm install
   ```

2. **Create Environment File**
   ```typescript
   // src/environments/environment.ts
   export const environment = {
     production: false,
     apiUrl: 'http://localhost:8080/api'
   };
   ```

3. **Run Development Server**
   ```bash
   ng serve
   ```
   
   Frontend will start on `http://localhost:4200`

## Key Features Implementation

### 1. User Authentication
- JWT-based authentication
- Secure password hashing with BCrypt
- Token-based session management
- Role-based access control

### 2. Trade Management
- Log trades with entry/exit prices
- Calculate P&L automatically
- Support for multiple asset types
- Track open and closed positions
- Add notes and screenshots

### 3. Performance Analytics
- Win rate calculation
- Profit factor analysis
- Average win/loss tracking
- Risk-reward ratio
- Total P&L tracking
- Largest win/loss identification

### 4. Account Management
- Multiple trading accounts per user
- Account balance tracking
- Automatic balance updates
- Support for different account types (Demo, Live, Paper)

## Security Features

- JWT token authentication
- Password encryption
- CORS configuration
- SQL injection prevention (JPA/Hibernate)
- XSS protection
- CSRF protection

## Development Guidelines

### Backend Code Standards
- Follow Spring Boot best practices
- Use DTOs for API communication
- Implement proper exception handling
- Write unit tests for services
- Use meaningful variable names
- Add JavaDoc comments for public methods

### Frontend Code Standards
- Follow Angular style guide
- Use TypeScript strictly
- Implement proper error handling
- Use RxJS for async operations
- Create reusable components
- Add comments for complex logic

## Future Enhancements

1. **AI-Powered Insights**
   - Trade pattern recognition
   - Strategy optimization suggestions
   - Risk management recommendations

2. **Advanced Analytics**
   - Equity curve visualization
   - Drawdown analysis
   - Monthly/yearly performance reports
   - Strategy backtesting

3. **Integration Features**
   - Broker API connections
   - Automated trade import
   - Real-time market data
   - Trading signals

4. **Collaboration**
   - Share trades with mentors
   - Trading journal templates
   - Community insights

5. **Mobile App**
   - iOS and Android apps
   - Push notifications
   - Quick trade logging

## Testing

### Backend Tests
```bash
cd backend
mvn test
```

### Frontend Tests
```bash
cd frontend
ng test
```

## Deployment

### Backend Deployment
1. Build JAR file: `mvn clean package`
2. Deploy to cloud platform (AWS, Azure, GCP)
3. Configure production database
4. Set environment variables
5. Enable SSL/TLS

### Frontend Deployment
1. Build production: `ng build --prod`
2. Deploy dist folder to hosting (Netlify, Vercel, S3)
3. Configure environment variables
4. Set up CDN

## License

This project is created for educational purposes.

## Support

For issues and questions, please create an issue in the repository.

## Contributors

- Your Name - Initial work

## Acknowledgments

- Inspired by tradediary.in
- Spring Boot documentation
- Angular documentation
- MSSQL documentation
