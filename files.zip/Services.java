package com.tradediary.service;

import com.tradediary.dto.*;
import com.tradediary.entity.Trade;
import com.tradediary.entity.TradingAccount;
import com.tradediary.entity.User;
import com.tradediary.exception.ResourceNotFoundException;
import com.tradediary.repository.Repositories.*;
import com.tradediary.security.JwtUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
class AuthService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtUtil jwtUtil;
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private CustomUserDetailsService userDetailsService;
    
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new RuntimeException("Username already exists");
        }
        
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }
        
        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setFullName(request.getFullName());
        user.setPhoneNumber(request.getPhoneNumber());
        user.setRole(User.Role.USER);
        user.setIsActive(true);
        user.setIsVerified(false);
        
        user = userRepository.save(user);
        
        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getUsername());
        String token = jwtUtil.generateToken(userDetails);
        
        return new AuthResponse(token, "Bearer", user.getId(), user.getUsername(), 
                               user.getEmail(), user.getRole());
    }
    
    public AuthResponse login(LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );
        
        SecurityContextHolder.getContext().setAuthentication(authentication);
        
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        String token = jwtUtil.generateToken(userDetails);
        
        User user = userRepository.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        return new AuthResponse(token, "Bearer", user.getId(), user.getUsername(), 
                               user.getEmail(), user.getRole());
    }
}

@Service
class TradingAccountService {
    
    @Autowired
    private TradingAccountRepository accountRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ModelMapper modelMapper;
    
    @Transactional
    public TradingAccountDTO createAccount(Long userId, TradingAccountRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        TradingAccount account = new TradingAccount();
        account.setUser(user);
        account.setAccountName(request.getAccountName());
        account.setBrokerName(request.getBrokerName());
        account.setAccountNumber(request.getAccountNumber());
        account.setAccountType(request.getAccountType());
        account.setInitialBalance(request.getInitialBalance());
        account.setCurrentBalance(request.getInitialBalance());
        account.setCurrency(request.getCurrency());
        account.setIsActive(true);
        
        account = accountRepository.save(account);
        
        return modelMapper.map(account, TradingAccountDTO.class);
    }
    
    public List<TradingAccountDTO> getUserAccounts(Long userId) {
        List<TradingAccount> accounts = accountRepository.findByUserId(userId);
        return accounts.stream()
                .map(account -> modelMapper.map(account, TradingAccountDTO.class))
                .collect(Collectors.toList());
    }
    
    public TradingAccountDTO getAccountById(Long userId, Long accountId) {
        TradingAccount account = accountRepository.findByIdAndUserId(accountId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        return modelMapper.map(account, TradingAccountDTO.class);
    }
    
    @Transactional
    public void updateAccountBalance(Long accountId, BigDecimal profitLoss) {
        TradingAccount account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        
        BigDecimal newBalance = account.getCurrentBalance().add(profitLoss);
        account.setCurrentBalance(newBalance);
        accountRepository.save(account);
    }
}

@Service
class TradeService {
    
    @Autowired
    private TradeRepository tradeRepository;
    
    @Autowired
    private TradingAccountRepository accountRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private TradingAccountService accountService;
    
    @Autowired
    private ModelMapper modelMapper;
    
    @Transactional
    public TradeDTO createTrade(Long userId, TradeRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        TradingAccount account = accountRepository.findByIdAndUserId(request.getAccountId(), userId)
                .orElseThrow(() -> new ResourceNotFoundException("Trading account not found"));
        
        Trade trade = new Trade();
        trade.setUser(user);
        trade.setTradingAccount(account);
        trade.setSymbol(request.getSymbol());
        trade.setTradeType(request.getTradeType());
        trade.setPositionType(request.getPositionType());
        trade.setEntryPrice(request.getEntryPrice());
        trade.setExitPrice(request.getExitPrice());
        trade.setQuantity(request.getQuantity());
        trade.setStopLoss(request.getStopLoss());
        trade.setTakeProfit(request.getTakeProfit());
        trade.setCommission(request.getCommission() != null ? request.getCommission() : BigDecimal.ZERO);
        trade.setEntryDate(request.getEntryDate());
        trade.setExitDate(request.getExitDate());
        trade.setStrategy(request.getStrategy());
        trade.setMarketCondition(request.getMarketCondition());
        trade.setNotes(request.getNotes());
        trade.setScreenshotUrl(request.getScreenshotUrl());
        trade.setTags(request.getTags());
        
        // Calculate P&L if exit price is provided
        if (request.getExitPrice() != null) {
            calculateProfitLoss(trade);
            trade.setStatus(Trade.TradeStatus.CLOSED);
            
            // Update account balance
            accountService.updateAccountBalance(account.getId(), trade.getNetProfitLoss());
        } else {
            trade.setStatus(Trade.TradeStatus.OPEN);
        }
        
        trade = tradeRepository.save(trade);
        
        return convertToDTO(trade);
    }
    
    @Transactional
    public TradeDTO closeTrade(Long userId, Long tradeId, BigDecimal exitPrice, LocalDateTime exitDate) {
        Trade trade = tradeRepository.findById(tradeId)
                .orElseThrow(() -> new ResourceNotFoundException("Trade not found"));
        
        if (!trade.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized access to trade");
        }
        
        if (trade.getStatus() == Trade.TradeStatus.CLOSED) {
            throw new RuntimeException("Trade is already closed");
        }
        
        trade.setExitPrice(exitPrice);
        trade.setExitDate(exitDate != null ? exitDate : LocalDateTime.now());
        trade.setStatus(Trade.TradeStatus.CLOSED);
        
        calculateProfitLoss(trade);
        trade = tradeRepository.save(trade);
        
        // Update account balance
        accountService.updateAccountBalance(trade.getTradingAccount().getId(), trade.getNetProfitLoss());
        
        return convertToDTO(trade);
    }
    
    public List<TradeDTO> getUserTrades(Long userId) {
        List<Trade> trades = tradeRepository.findByUserId(userId);
        return trades.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
    
    public List<TradeDTO> getTradesByAccount(Long userId, Long accountId) {
        // Verify account belongs to user
        accountRepository.findByIdAndUserId(accountId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Trading account not found"));
        
        List<Trade> trades = tradeRepository.findByTradingAccountId(accountId);
        return trades.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
    
    public TradeStatistics getTradeStatistics(Long userId) {
        List<Trade> closedTrades = tradeRepository.findByUserIdAndStatus(userId, Trade.TradeStatus.CLOSED);
        
        if (closedTrades.isEmpty()) {
            return new TradeStatistics(0L, 0L, 0L, BigDecimal.ZERO, BigDecimal.ZERO, 
                                     BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, 
                                     BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, 
                                     BigDecimal.ZERO, BigDecimal.ZERO);
        }
        
        Long totalTrades = (long) closedTrades.size();
        Long winningTrades = closedTrades.stream().filter(t -> t.getNetProfitLoss().compareTo(BigDecimal.ZERO) > 0).count();
        Long losingTrades = closedTrades.stream().filter(t -> t.getNetProfitLoss().compareTo(BigDecimal.ZERO) < 0).count();
        
        BigDecimal winRate = totalTrades > 0 ? 
                BigDecimal.valueOf(winningTrades).divide(BigDecimal.valueOf(totalTrades), 4, RoundingMode.HALF_UP)
                        .multiply(BigDecimal.valueOf(100)) : BigDecimal.ZERO;
        
        BigDecimal totalProfit = closedTrades.stream()
                .filter(t -> t.getNetProfitLoss().compareTo(BigDecimal.ZERO) > 0)
                .map(Trade::getNetProfitLoss)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal totalLoss = closedTrades.stream()
                .filter(t -> t.getNetProfitLoss().compareTo(BigDecimal.ZERO) < 0)
                .map(Trade::getNetProfitLoss)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal netProfitLoss = totalProfit.add(totalLoss);
        
        BigDecimal averageWin = winningTrades > 0 ? 
                totalProfit.divide(BigDecimal.valueOf(winningTrades), 2, RoundingMode.HALF_UP) : BigDecimal.ZERO;
        
        BigDecimal averageLoss = losingTrades > 0 ? 
                totalLoss.divide(BigDecimal.valueOf(losingTrades), 2, RoundingMode.HALF_UP) : BigDecimal.ZERO;
        
        BigDecimal profitFactor = totalLoss.compareTo(BigDecimal.ZERO) != 0 ? 
                totalProfit.divide(totalLoss.abs(), 2, RoundingMode.HALF_UP) : BigDecimal.ZERO;
        
        BigDecimal largestWin = closedTrades.stream()
                .map(Trade::getNetProfitLoss)
                .max(BigDecimal::compareTo)
                .orElse(BigDecimal.ZERO);
        
        BigDecimal largestLoss = closedTrades.stream()
                .map(Trade::getNetProfitLoss)
                .min(BigDecimal::compareTo)
                .orElse(BigDecimal.ZERO);
        
        BigDecimal averageRiskReward = averageLoss.compareTo(BigDecimal.ZERO) != 0 ? 
                averageWin.divide(averageLoss.abs(), 2, RoundingMode.HALF_UP) : BigDecimal.ZERO;
        
        return new TradeStatistics(totalTrades, winningTrades, losingTrades, winRate, 
                                 totalProfit, totalLoss, netProfitLoss, averageWin, 
                                 averageLoss, profitFactor, largestWin, largestLoss, 
                                 averageRiskReward);
    }
    
    private void calculateProfitLoss(Trade trade) {
        BigDecimal priceDifference;
        
        if (trade.getPositionType() == Trade.PositionType.LONG) {
            priceDifference = trade.getExitPrice().subtract(trade.getEntryPrice());
        } else {
            priceDifference = trade.getEntryPrice().subtract(trade.getExitPrice());
        }
        
        BigDecimal profitLoss = priceDifference.multiply(trade.getQuantity());
        trade.setProfitLoss(profitLoss);
        
        BigDecimal netProfitLoss = profitLoss.subtract(trade.getCommission());
        trade.setNetProfitLoss(netProfitLoss);
        
        BigDecimal totalInvestment = trade.getEntryPrice().multiply(trade.getQuantity());
        BigDecimal profitLossPercentage = totalInvestment.compareTo(BigDecimal.ZERO) != 0 ?
                profitLoss.divide(totalInvestment, 4, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100)) :
                BigDecimal.ZERO;
        trade.setProfitLossPercentage(profitLossPercentage);
    }
    
    private TradeDTO convertToDTO(Trade trade) {
        TradeDTO dto = modelMapper.map(trade, TradeDTO.class);
        dto.setAccountId(trade.getTradingAccount().getId());
        dto.setAccountName(trade.getTradingAccount().getAccountName());
        return dto;
    }
}
