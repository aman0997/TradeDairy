import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { TradingAccount, ApiResponse } from '../models/models';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  private apiUrl = `${environment.apiUrl}/accounts`;

  constructor(private http: HttpClient) {}

  createAccount(account: Partial<TradingAccount>): Observable<TradingAccount> {
    return this.http.post<ApiResponse<TradingAccount>>(this.apiUrl, account)
      .pipe(map(response => response.data));
  }

  getAllAccounts(): Observable<TradingAccount[]> {
    return this.http.get<ApiResponse<TradingAccount[]>>(this.apiUrl)
      .pipe(map(response => response.data));
  }

  getAccountById(accountId: number): Observable<TradingAccount> {
    return this.http.get<ApiResponse<TradingAccount>>(`${this.apiUrl}/${accountId}`)
      .pipe(map(response => response.data));
  }
}
