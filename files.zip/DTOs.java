package com.tradediary.dto;

import com.tradediary.entity.Trade;
import com.tradediary.entity.TradingAccount;
import com.tradediary.entity.User;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;

// Auth DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
class LoginRequest {
    @NotBlank(message = "Username is required")
    private String username;
    
    @NotBlank(message = "Password is required")
    private String password;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class RegisterRequest {
    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 50)
    private String username;
    
    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;
    
    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;
    
    private String fullName;
    private String phoneNumber;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class AuthResponse {
    private String token;
    private String type = "Bearer";
    private Long userId;
    private String username;
    private String email;
    private User.Role role;
}

// User DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
class UserDTO {
    private Long id;
    private String username;
    private String email;
    private String fullName;
    private String phoneNumber;
    private User.Role role;
    private Boolean isActive;
    private Boolean isVerified;
    private LocalDateTime createdAt;
}

// Trading Account DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
class TradingAccountRequest {
    @NotBlank(message = "Account name is required")
    private String accountName;
    
    private String brokerName;
    private String accountNumber;
    
    @NotNull(message = "Account type is required")
    private TradingAccount.AccountType accountType;
    
    @NotNull(message = "Initial balance is required")
    @DecimalMin(value = "0.0", inclusive = false)
    private BigDecimal initialBalance;
    
    @Size(min = 3, max = 3)
    private String currency = "USD";
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class TradingAccountDTO {
    private Long id;
    private String accountName;
    private String brokerName;
    private String accountNumber;
    private TradingAccount.AccountType accountType;
    private BigDecimal initialBalance;
    private BigDecimal currentBalance;
    private String currency;
    private Boolean isActive;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

// Trade DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
class TradeRequest {
    @NotNull(message = "Account ID is required")
    private Long accountId;
    
    @NotBlank(message = "Symbol is required")
    private String symbol;
    
    @NotNull(message = "Trade type is required")
    private Trade.TradeType tradeType;
    
    @NotNull(message = "Position type is required")
    private Trade.PositionType positionType;
    
    @NotNull(message = "Entry price is required")
    @DecimalMin(value = "0.0", inclusive = false)
    private BigDecimal entryPrice;
    
    private BigDecimal exitPrice;
    
    @NotNull(message = "Quantity is required")
    @DecimalMin(value = "0.0", inclusive = false)
    private BigDecimal quantity;
    
    private BigDecimal stopLoss;
    private BigDecimal takeProfit;
    private BigDecimal commission;
    
    @NotNull(message = "Entry date is required")
    private LocalDateTime entryDate;
    
    private LocalDateTime exitDate;
    private String strategy;
    private String marketCondition;
    private String notes;
    private String screenshotUrl;
    private Set<String> tags;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class TradeDTO {
    private Long id;
    private Long accountId;
    private String accountName;
    private String symbol;
    private Trade.TradeType tradeType;
    private Trade.PositionType positionType;
    private BigDecimal entryPrice;
    private BigDecimal exitPrice;
    private BigDecimal quantity;
    private BigDecimal stopLoss;
    private BigDecimal takeProfit;
    private BigDecimal profitLoss;
    private BigDecimal profitLossPercentage;
    private BigDecimal commission;
    private BigDecimal netProfitLoss;
    private Trade.TradeStatus status;
    private LocalDateTime entryDate;
    private LocalDateTime exitDate;
    private String strategy;
    private String marketCondition;
    private String notes;
    private String screenshotUrl;
    private Set<String> tags;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

// Statistics DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
class TradeStatistics {
    private Long totalTrades;
    private Long winningTrades;
    private Long losingTrades;
    private BigDecimal winRate;
    private BigDecimal totalProfit;
    private BigDecimal totalLoss;
    private BigDecimal netProfitLoss;
    private BigDecimal averageWin;
    private BigDecimal averageLoss;
    private BigDecimal profitFactor;
    private BigDecimal largestWin;
    private BigDecimal largestLoss;
    private BigDecimal averageRiskReward;
}

// API Response wrapper
@Data
@NoArgsConstructor
@AllArgsConstructor
class ApiResponse<T> {
    private boolean success;
    private String message;
    private T data;
    
    public static <T> ApiResponse<T> success(String message, T data) {
        return new ApiResponse<>(true, message, data);
    }
    
    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>(false, message, null);
    }
}
