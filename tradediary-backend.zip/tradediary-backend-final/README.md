# TradeDiary Backend - Spring Boot Application

Trading Journal REST API built with Spring Boot 3.2.1 and MSSQL Server.

## Technology Stack

- **Framework**: Spring Boot 3.2.1
- **Language**: Java 17
- **Database**: Microsoft SQL Server 2019+
- **Security**: Spring Security with JWT
- **ORM**: Spring Data JPA (Hibernate)
- **Build Tool**: Maven
- **API Documentation**: SpringDoc OpenAPI (Swagger)

## Project Structure

```
tradediary-backend/
├── pom.xml                                    # Maven dependencies
├── Dockerfile                                 # Docker configuration
├── README.md                                  # This file
├── src/
│   ├── main/
│   │   ├── java/com/tradediary/
│   │   │   ├── TradeDiaryApplication.java    # Main application
│   │   │   ├── config/
│   │   │   │   └── SecurityConfig.java       # Security configuration
│   │   │   ├── controller/
│   │   │   │   └── Controllers.java          # REST endpoints
│   │   │   ├── dto/
│   │   │   │   └── DTOs.java                 # Data Transfer Objects
│   │   │   ├── entity/
│   │   │   │   ├── User.java
│   │   │   │   ├── TradingAccount.java
│   │   │   │   └── Trade.java
│   │   │   ├── exception/
│   │   │   │   └── ResourceNotFoundException.java
│   │   │   ├── repository/
│   │   │   │   └── Repositories.java         # JPA Repositories
│   │   │   ├── security/
│   │   │   │   ├── JwtUtil.java
│   │   │   │   └── JwtAuthenticationFilter.java
│   │   │   └── service/
│   │   │       ├── Services.java             # Business logic
│   │   │       └── CustomUserDetailsService.java
│   │   └── resources/
│   │       └── application.properties
│   └── test/java/com/tradediary/            # Unit tests
└── target/                                    # Build output (generated)
```

## Prerequisites

- Java 17 or higher
- Maven 3.6+
- Microsoft SQL Server 2019+ (or Docker)

## Quick Start

### 1. Setup Database

**Option A: Using Docker**
```bash
docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourStrong@Passw0rd" \
  -p 1433:1433 --name mssql-server \
  -d mcr.microsoft.com/mssql/server:2022-latest
```

**Option B: Using existing MSSQL Server**
Create a database named `tradediary_db`

### 2. Configure Application

Edit `src/main/resources/application.properties`:

```properties
# Update these values for your environment
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=tradediary_db;encrypt=true;trustServerCertificate=true
spring.datasource.username=sa
spring.datasource.password=YourStrong@Passw0rd

# Change this in production!
jwt.secret=TradeDiarySecretKeyForJWTTokenGenerationPleaseChangeInProduction2024
```

### 3. Build and Run

```bash
# Build the project
mvn clean install

# Run the application
mvn spring-boot:run
```

The API will be available at: `http://localhost:8080/api`

### 4. Access Swagger UI

Open: `http://localhost:8080/api/swagger-ui.html`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Trading Accounts
- `GET /api/accounts` - Get all user accounts
- `POST /api/accounts` - Create new account
- `GET /api/accounts/{id}` - Get account by ID

### Trades
- `GET /api/trades` - Get all user trades
- `POST /api/trades` - Create new trade
- `PUT /api/trades/{id}/close` - Close a trade
- `GET /api/trades/account/{accountId}` - Get trades by account
- `GET /api/trades/statistics` - Get trading statistics

## Sample API Usage

### Register User
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "trader1",
    "email": "trader1@example.com",
    "password": "securepass123",
    "fullName": "John Trader"
  }'
```

### Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "trader1",
    "password": "securepass123"
  }'
```

Save the JWT token from the response.

### Create Trading Account
```bash
curl -X POST http://localhost:8080/api/accounts \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "accountName": "Live Trading Account",
    "brokerName": "Interactive Brokers",
    "accountType": "LIVE",
    "initialBalance": 50000,
    "currency": "USD"
  }'
```

### Log a Trade
```bash
curl -X POST http://localhost:8080/api/trades \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "accountId": 1,
    "symbol": "AAPL",
    "tradeType": "STOCK",
    "positionType": "LONG",
    "entryPrice": 175.50,
    "quantity": 100,
    "stopLoss": 170.00,
    "takeProfit": 185.00,
    "entryDate": "2024-02-16T09:30:00",
    "strategy": "Momentum",
    "notes": "Bullish breakout pattern"
  }'
```

### Get Statistics
```bash
curl -X GET http://localhost:8080/api/trades/statistics \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

## Database Schema

### Users
- id, username, email, password (encrypted)
- full_name, phone_number
- role (USER, ADMIN, PREMIUM)
- is_active, is_verified
- created_at, updated_at

### Trading Accounts
- id, user_id
- account_name, broker_name, account_number
- account_type (DEMO, LIVE, PAPER)
- initial_balance, current_balance, currency
- is_active, created_at, updated_at

### Trades
- id, user_id, account_id
- symbol, trade_type, position_type
- entry_price, exit_price, quantity
- stop_loss, take_profit
- profit_loss, profit_loss_percentage
- commission, net_profit_loss
- status (OPEN, CLOSED, CANCELLED)
- entry_date, exit_date
- strategy, market_condition, notes
- screenshot_url, tags
- created_at, updated_at

## Features

✅ JWT-based authentication and authorization
✅ Automatic P&L calculation for trades
✅ Multiple trading accounts per user
✅ Comprehensive trading statistics
✅ Win rate and profit factor analysis
✅ Trade categorization by strategy
✅ RESTful API design
✅ Swagger/OpenAPI documentation
✅ CORS configuration for frontend integration
✅ Exception handling
✅ Input validation
✅ Password encryption with BCrypt

## Configuration

### application.properties

```properties
# Server Configuration
server.port=8080
server.servlet.context-path=/api

# Database Configuration
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=tradediary_db
spring.datasource.username=sa
spring.datasource.password=YourStrong@Passw0rd
spring.datasource.driver-class-name=com.microsoft.sqlserver.jdbc.SQLServerDriver

# JPA/Hibernate
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.SQLServerDialect

# JWT Configuration
jwt.secret=your-secret-key
jwt.expiration=86400000

# CORS
cors.allowed-origins=http://localhost:4200

# Swagger/OpenAPI
springdoc.api-docs.path=/api-docs
springdoc.swagger-ui.path=/swagger-ui.html
```

## Build & Deploy

### Build JAR file
```bash
mvn clean package
```

The JAR file will be in `target/tradediary-backend-1.0.0.jar`

### Run JAR
```bash
java -jar target/tradediary-backend-1.0.0.jar
```

### Docker Build
```bash
docker build -t tradediary-backend .
docker run -p 8080:8080 tradediary-backend
```

## Testing

```bash
# Run all tests
mvn test

# Run with coverage
mvn test jacoco:report
```

## Development

### Adding New Endpoint

1. Create DTO in `dto/DTOs.java`
2. Add method in appropriate Service
3. Create endpoint in Controller
4. Test in Swagger UI

### Database Schema Changes

The application uses Hibernate auto-DDL. Changes to entities automatically update the schema.

For production, set:
```properties
spring.jpa.hibernate.ddl-auto=validate
```

And use database migration tools like Flyway or Liquibase.

## Security

- Passwords encrypted with BCrypt
- JWT tokens for stateless authentication
- CORS configured for specific origins
- SQL injection protection (JPA/Hibernate)
- Input validation on all endpoints

## Performance Optimization

- Connection pooling configured
- Hibernate batch operations enabled
- Indexes on frequently queried columns
- Lazy loading for associations

## Troubleshooting

### Cannot connect to database
- Verify MSSQL is running
- Check connection string
- Verify credentials
- Check firewall settings

### Port 8080 already in use
```bash
lsof -ti:8080 | xargs kill -9
```

### JWT authentication fails
- Check JWT secret configuration
- Verify token hasn't expired
- Ensure Bearer prefix in Authorization header

## Production Deployment

1. Change `jwt.secret` to a strong random value
2. Set `spring.jpa.hibernate.ddl-auto=validate`
3. Configure production database
4. Enable HTTPS
5. Set up logging and monitoring
6. Configure reverse proxy (Nginx/Apache)
7. Set up database backups

## Dependencies

Key Maven dependencies:
- spring-boot-starter-web
- spring-boot-starter-data-jpa
- spring-boot-starter-security
- mssql-jdbc
- jjwt (JWT library)
- lombok
- modelmapper
- springdoc-openapi

## License

Educational/Commercial use allowed.

## Support

For issues and questions:
1. Check Swagger documentation
2. Review application logs
3. Check database connectivity
4. Verify configuration

## Contributing

1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create pull request

---

Built with ❤️ using Spring Boot and MSSQL Server
