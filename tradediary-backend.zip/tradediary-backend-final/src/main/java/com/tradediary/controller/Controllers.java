package com.tradediary.controller;

import com.tradediary.dto.*;
import com.tradediary.service.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*")
class AuthController {
    
    @Autowired
    private AuthService authService;
    
    @PostMapping("/register")
    public ResponseEntity<ApiResponse<AuthResponse>> register(@Valid @RequestBody RegisterRequest request) {
        try {
            AuthResponse response = authService.register(request);
            return ResponseEntity.ok(ApiResponse.success("User registered successfully", response));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(@Valid @RequestBody LoginRequest request) {
        try {
            AuthResponse response = authService.login(request);
            return ResponseEntity.ok(ApiResponse.success("Login successful", response));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Invalid credentials"));
        }
    }
}

@RestController
@RequestMapping("/accounts")
@CrossOrigin(origins = "*")
class TradingAccountController {
    
    @Autowired
    private TradingAccountService accountService;
    
    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return 1L;
    }
    
    @PostMapping
    public ResponseEntity<ApiResponse<TradingAccountDTO>> createAccount(@Valid @RequestBody TradingAccountRequest request) {
        try {
            Long userId = getCurrentUserId();
            TradingAccountDTO account = accountService.createAccount(userId, request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Trading account created successfully", account));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping
    public ResponseEntity<ApiResponse<List<TradingAccountDTO>>> getUserAccounts() {
        try {
            Long userId = getCurrentUserId();
            List<TradingAccountDTO> accounts = accountService.getUserAccounts(userId);
            return ResponseEntity.ok(ApiResponse.success("Accounts retrieved successfully", accounts));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/{accountId}")
    public ResponseEntity<ApiResponse<TradingAccountDTO>> getAccountById(@PathVariable Long accountId) {
        try {
            Long userId = getCurrentUserId();
            TradingAccountDTO account = accountService.getAccountById(userId, accountId);
            return ResponseEntity.ok(ApiResponse.success("Account retrieved successfully", account));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
}

@RestController
@RequestMapping("/trades")
@CrossOrigin(origins = "*")
class TradeController {
    
    @Autowired
    private TradeService tradeService;
    
    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return 1L;
    }
    
    @PostMapping
    public ResponseEntity<ApiResponse<TradeDTO>> createTrade(@Valid @RequestBody TradeRequest request) {
        try {
            Long userId = getCurrentUserId();
            TradeDTO trade = tradeService.createTrade(userId, request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Trade created successfully", trade));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @PutMapping("/{tradeId}/close")
    public ResponseEntity<ApiResponse<TradeDTO>> closeTrade(
            @PathVariable Long tradeId,
            @RequestParam BigDecimal exitPrice,
            @RequestParam(required = false) LocalDateTime exitDate) {
        try {
            Long userId = getCurrentUserId();
            TradeDTO trade = tradeService.closeTrade(userId, tradeId, exitPrice, exitDate);
            return ResponseEntity.ok(ApiResponse.success("Trade closed successfully", trade));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping
    public ResponseEntity<ApiResponse<List<TradeDTO>>> getUserTrades() {
        try {
            Long userId = getCurrentUserId();
            List<TradeDTO> trades = tradeService.getUserTrades(userId);
            return ResponseEntity.ok(ApiResponse.success("Trades retrieved successfully", trades));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/account/{accountId}")
    public ResponseEntity<ApiResponse<List<TradeDTO>>> getTradesByAccount(@PathVariable Long accountId) {
        try {
            Long userId = getCurrentUserId();
            List<TradeDTO> trades = tradeService.getTradesByAccount(userId, accountId);
            return ResponseEntity.ok(ApiResponse.success("Trades retrieved successfully", trades));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/statistics")
    public ResponseEntity<ApiResponse<TradeStatistics>> getStatistics() {
        try {
            Long userId = getCurrentUserId();
            TradeStatistics stats = tradeService.getTradeStatistics(userId);
            return ResponseEntity.ok(ApiResponse.success("Statistics retrieved successfully", stats));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
}
