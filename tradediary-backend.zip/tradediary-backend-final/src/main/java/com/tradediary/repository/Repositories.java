package com.tradediary.repository;

import com.tradediary.entity.Trade;
import com.tradediary.entity.TradingAccount;
import com.tradediary.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    Boolean existsByUsername(String username);
    Boolean existsByEmail(String email);
    Optional<User> findByVerificationToken(String token);
    Optional<User> findByResetToken(String token);
}

@Repository
interface TradingAccountRepository extends JpaRepository<TradingAccount, Long> {
    List<TradingAccount> findByUserId(Long userId);
    List<TradingAccount> findByUserIdAndIsActive(Long userId, Boolean isActive);
    Optional<TradingAccount> findByIdAndUserId(Long id, Long userId);
}

@Repository
interface TradeRepository extends JpaRepository<Trade, Long> {
    List<Trade> findByUserId(Long userId);
    List<Trade> findByTradingAccountId(Long accountId);
    List<Trade> findByUserIdAndStatus(Long userId, Trade.TradeStatus status);
    List<Trade> findByUserIdAndEntryDateBetween(Long userId, LocalDateTime startDate, LocalDateTime endDate);
    
    @Query("SELECT t FROM Trade t WHERE t.user.id = :userId AND t.entryDate >= :startDate AND t.entryDate <= :endDate")
    List<Trade> findTradesByUserAndDateRange(@Param("userId") Long userId, 
                                              @Param("startDate") LocalDateTime startDate, 
                                              @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT t FROM Trade t WHERE t.user.id = :userId AND t.strategy = :strategy")
    List<Trade> findByUserIdAndStrategy(@Param("userId") Long userId, @Param("strategy") String strategy);
    
    @Query("SELECT COUNT(t) FROM Trade t WHERE t.user.id = :userId AND t.status = :status")
    Long countByUserIdAndStatus(@Param("userId") Long userId, @Param("status") Trade.TradeStatus status);
    
    @Query("SELECT COUNT(t) FROM Trade t WHERE t.user.id = :userId AND t.netProfitLoss > 0")
    Long countWinningTrades(@Param("userId") Long userId);
    
    @Query("SELECT COUNT(t) FROM Trade t WHERE t.user.id = :userId AND t.netProfitLoss < 0")
    Long countLosingTrades(@Param("userId") Long userId);
    
    @Query("SELECT SUM(t.netProfitLoss) FROM Trade t WHERE t.user.id = :userId AND t.status = 'CLOSED'")
    java.math.BigDecimal calculateTotalProfitLoss(@Param("userId") Long userId);
}
