package com.tradediary.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "trades")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Trade {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id", nullable = false)
    private TradingAccount tradingAccount;
    
    @Column(nullable = false)
    private String symbol;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "trade_type", nullable = false)
    private TradeType tradeType;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "position_type", nullable = false)
    private PositionType positionType;
    
    @Column(name = "entry_price", precision = 15, scale = 2, nullable = false)
    private BigDecimal entryPrice;
    
    @Column(name = "exit_price", precision = 15, scale = 2)
    private BigDecimal exitPrice;
    
    @Column(precision = 15, scale = 2, nullable = false)
    private BigDecimal quantity;
    
    @Column(name = "stop_loss", precision = 15, scale = 2)
    private BigDecimal stopLoss;
    
    @Column(name = "take_profit", precision = 15, scale = 2)
    private BigDecimal takeProfit;
    
    @Column(name = "profit_loss", precision = 15, scale = 2)
    private BigDecimal profitLoss;
    
    @Column(name = "profit_loss_percentage", precision = 10, scale = 2)
    private BigDecimal profitLossPercentage;
    
    @Column(precision = 15, scale = 2)
    private BigDecimal commission;
    
    @Column(name = "net_profit_loss", precision = 15, scale = 2)
    private BigDecimal netProfitLoss;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TradeStatus status = TradeStatus.OPEN;
    
    @Column(name = "entry_date", nullable = false)
    private LocalDateTime entryDate;
    
    @Column(name = "exit_date")
    private LocalDateTime exitDate;
    
    @Column(length = 50)
    private String strategy;
    
    @Column(name = "market_condition", length = 50)
    private String marketCondition;
    
    @Column(columnDefinition = "TEXT")
    private String notes;
    
    @Column(name = "screenshot_url")
    private String screenshotUrl;
    
    @ElementCollection
    @CollectionTable(name = "trade_tags", joinColumns = @JoinColumn(name = "trade_id"))
    @Column(name = "tag")
    private Set<String> tags = new HashSet<>();
    
    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    public enum TradeType {
        STOCK, FOREX, CRYPTO, FUTURES, OPTIONS
    }
    
    public enum PositionType {
        LONG, SHORT
    }
    
    public enum TradeStatus {
        OPEN, CLOSED, CANCELLED
    }
}
