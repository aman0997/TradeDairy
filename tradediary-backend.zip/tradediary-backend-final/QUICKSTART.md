# Backend Quick Start

## Prerequisites
- Java 17+
- Maven 3.6+
- MSSQL Server (or Docker)

## Setup in 3 Steps

### 1. Setup Database

**Using Docker (Recommended):**
```bash
docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourStrong@Passw0rd" \
  -p 1433:1433 --name mssql-server \
  -d mcr.microsoft.com/mssql/server:2022-latest
```

The database will be auto-created by Hibernate on first run.

### 2. Configure

Edit `src/main/resources/application.properties`:
```properties
spring.datasource.username=sa
spring.datasource.password=YourStrong@Passw0rd
```

### 3. Run

```bash
mvn clean install
mvn spring-boot:run
```

✅ Backend running at: http://localhost:8080/api
✅ Swagger UI at: http://localhost:8080/api/swagger-ui.html

## Test API

Register user:
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"test","email":"test@test.com","password":"test123"}'
```

## IntelliJ IDEA Setup

1. Open folder as Maven project
2. Wait for dependencies to download
3. Run TradeDiaryApplication.java

## Troubleshooting

**Cannot connect to database?**
- Verify MSSQL is running: `docker ps`
- Check connection string in application.properties

**Port 8080 in use?**
```bash
lsof -ti:8080 | xargs kill -9
```
